import React from 'react';
function Vehicleappd({data}) {

  return (
    <div>
      
      
      <h2>Your Application number is <p style={{ color: "blue" }}>{data}</p></h2>
      
      
      <h4><i>*Your Vehicle application request is submitted please check after sometime for confirmation*</i></h4>
    </div>
  )
}

export default Vehicleappd;
