import React from "react";
import { useState } from "react";
import Axios from 'axios';
function InsertRTO(){
    const [RTOstate,setState]=useState("");
    const [RTOdistrict,setDistrict]=useState("");
    const [RTOaddress,setAddress]=useState(0);
    const [RTOpincode,setPincode]=useState(0);
    const [RTOcontact,setContact]=useState("");
    const [RTOoid,setOid]=useState("");
    
    const insertrtodb =() =>{
       
        Axios.post('http://localhost:3001/insert_rto',{
            State:RTOstate,
            District:RTOdistrict,
            Address:RTOaddress,
            Pincode:RTOpincode,
            Contact:RTOcontact,
            OfficeID:RTOoid,
        }).then(()=>{
            console.log("Inserted");
        });

    };



    return (
      
                <form>
                <div class="mb-3 row">
                    <label for="staticid" class="col-sm-2 col-form-label">
                        State:
                    </label>
                    <div class="col-sm-10">
                    <input
                        type="text"
                        readonly
                        class="form-control-plaintext"
                        id="staticid"
                        onChange={(event) => {
                        setState(event.target.value);
                        }}
                    />
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="staticEmail" class="col-sm-2 col-form-label">
                    District
                    </label>
                    <div class="col-sm-10">
                    <input
                        type="text"
                        readonly
                        class="form-control-plaintext"
                        id="staticEmail"
                        onChange={(event) => {
                        setDistrict(event.target.value);
                        }}
                    />
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="inputPassword" class="col-sm-2 col-form-label">
                    Address
                    </label>
                    <div class="col-sm-10">
                    <input
                        type="text"
                        class="form-control"
                        id="staticid"
                        onChange={(event) => {
                        setAddress(event.target.value);
                        }}
                    />
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="staticcode" class="col-sm-2 col-form-label">
                    PinCode
                    </label>
                    <div class="col-sm-10">
                    <input
                        type="text"
                        readonly
                        class="form-control-plaintext"
                        id="staticcode"
                        onChange={(event) => {
                        setPincode(event.target.value);
                        }}
                    />
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="staticcode" class="col-sm-2 col-form-label">
                    Contact
                    </label>
                    <div class="col-sm-10">
                    <input
                        type="text"
                        readonly
                        class="form-control-plaintext"
                        id="staticcode"
                        onChange={(event) => {
                        setContact(event.target.value);
                        }}
                    />
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="staticcode" class="col-sm-2 col-form-label">
                    Office ID
                    </label>
                    <div class="col-sm-10">
                    <input
                        type="text"
                        readonly
                        class="form-control-plaintext"
                        id="staticcode"
                        onChange={(event) => {
                        setOid(event.target.value);
                        }}
                    />
                    </div>
                </div>
                <div class="col-12">
                    <button type="submit" class="btn btn-primary" onClick={insertrtodb}>
                    Insert
                    </button>
                </div>
                </form>
      
    );
}
export default InsertRTO;
