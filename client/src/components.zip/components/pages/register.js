import React from 'react';
import Axios from 'axios';
import { useState } from "react";

function Signup() {
    const [userid, setUserid] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [code, setCode] = useState("");
    const type = "public";
    const adduser = () => {
        Axios.post("http://localhost:3001/insert_login_details", {
          userid: userid,
          email: email,
          password: password,
          code: code,
          type: type,
        }).then(() => {
            console.log("Succeeded");
        });
    };
  return (
      <form>
      <div class="mb-3 row">
    <label for="staticid" class="col-sm-2 col-form-label">UserID:</label>
    <div class="col-sm-10">
      <input type="text" readonly class="form-control-plaintext" id="staticid" onChange={(event) => {
            setUserid(event.target.value);
          }}
          />
    </div>
  </div>
    <div class="mb-3 row">
    <label for="staticEmail" class="col-sm-2 col-form-label">Email</label>
    <div class="col-sm-10">
      <input type="text" readonly class="form-control-plaintext" id="staticEmail"  onChange={(event) => {
            setEmail(event.target.value);
          }}
          />
    </div>
  </div>
  <div class="mb-3 row">
    <label for="inputPassword" class="col-sm-2 col-form-label">Password</label>
    <div class="col-sm-10">
      <input type="password" class="form-control" id="inputPassword" onChange={(event) => {
            setPassword(event.target.value);
          }}
          />
    </div>
  </div>
  <div class="mb-3 row">
    <label for="staticcode" class="col-sm-2 col-form-label">Security Code:</label>
    <div class="col-sm-10">
      <input type="text" readonly class="form-control-plaintext" id="staticcode" onChange={(event) => {
            setCode(event.target.value);
          }}
          />
    </div>
  </div>
  <div class="col-12">
    <button type="submit" class="btn btn-primary" onClick={adduser}>Register</button>
  </div>
  </form>
  )
}

export default Signup;
