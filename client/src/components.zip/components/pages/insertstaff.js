import React from "react";
import { useState } from "react";
import Axios from 'axios';
function InsertStaff(){
    const [StaffName,setSName]=useState("");
    const [StaffID,setStaffid]=useState("");
    const [Scontact,setStaffcontact]=useState(0);
    const [StaffSal,setStaffSalary]=useState(0);
    const [StaffPos,setStaffPos]=useState("");
    const [StaffOfficeID,setStaffOid]=useState("");
    
    const insertstaffdb =() =>{
       
        Axios.post('http://localhost:3001/insert_staff',{
            Staffname:StaffName,
            Staffid:StaffID,
            StaffContact:Scontact,
            StaffSalary:StaffSal,
            StaffPosition:StaffPos,
            StaffOID:StaffOfficeID,
        }).then(()=>{
            console.log("Inserted");
        });

    };



    return (
      
                <form>
                <div class="mb-3 row">
                    <label for="staticid" class="col-sm-2 col-form-label">
                        Staff Name:
                    </label>
                    <div class="col-sm-10">
                    <input
                        type="text"
                        readonly
                        class="form-control-plaintext"
                        id="staticid"
                        onChange={(event) => {
                        setSName(event.target.value);
                        }}
                    />
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="staticEmail" class="col-sm-2 col-form-label">
                    Staff ID
                    </label>
                    <div class="col-sm-10">
                    <input
                        type="text"
                        readonly
                        class="form-control-plaintext"
                        id="staticEmail"
                        onChange={(event) => {
                        setStaffid(event.target.value);
                        }}
                    />
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="inputPassword" class="col-sm-2 col-form-label">
                    Contact
                    </label>
                    <div class="col-sm-10">
                    <input
                        type="text"
                        class="form-control"
                        id="staticid"
                        onChange={(event) => {
                        setStaffcontact(event.target.value);
                        }}
                    />
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="staticcode" class="col-sm-2 col-form-label">
                    Salary
                    </label>
                    <div class="col-sm-10">
                    <input
                        type="text"
                        readonly
                        class="form-control-plaintext"
                        id="staticcode"
                        onChange={(event) => {
                        setStaffSalary(event.target.value);
                        }}
                    />
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="staticcode" class="col-sm-2 col-form-label">
                    Position
                    </label>
                    <div class="col-sm-10">
                    <input
                        type="text"
                        readonly
                        class="form-control-plaintext"
                        id="staticcode"
                        onChange={(event) => {
                        setStaffPos(event.target.value);
                        }}
                    />
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="staticcode" class="col-sm-2 col-form-label">
                    Office ID
                    </label>
                    <div class="col-sm-10">
                    <input
                        type="text"
                        readonly
                        class="form-control-plaintext"
                        id="staticcode"
                        onChange={(event) => {
                        setStaffOid(event.target.value);
                        }}
                    />
                    </div>
                </div>
                <div class="col-12">
                    <button type="submit" class="btn btn-primary" onClick={insertstaffdb}>
                    Insert
                    </button>
                </div>
                </form>
      
    );
}
export default InsertStaff;
