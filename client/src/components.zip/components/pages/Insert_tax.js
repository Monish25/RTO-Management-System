import React, { useState } from 'react';
import Axios from 'axios';
function Insert_tax() {
        
    const [invoiceid, setInvoiceid] = useState("");
    const [tov, setTov] = useState("");
    const [payment, setPayment] = useState("");
    const [regno, setRegno] = useState("");
    const [amount, setAmount] = useState("");
    const tax = () => {    
        Axios.post("http://localhost:3001/insert_tax",{
            Invoice_ID: invoiceid,
            Amount: amount,
            Type_of_vehicle: tov,
             Payment_methods: payment,
             Reg_number: regno,
          }
          ).then(() => {
              
               console.log("suceeded");
          });
      };
  return (
    <form class="row g-3">
    <div><h3><centre>TAX DETAILS</centre></h3></div>
    <div class="mb-3 row">
<label for="staticid" class="col-sm-2 col-form-label">Invoice_ID</label>
<div class="col-sm-10">
<input type="text" readonly class="form-control" id="staticid" onChange={(event) => {
            setInvoiceid(event.target.value);
          }}
   />
</div>
</div>

<div class="mb-3 row">
<label for="statiaid" class="col-sm-2 col-form-label">Amount:</label>
<div class="col-sm-10">
<input type="text" readonly class="form-control" id="staticid" onChange={(event) => {
            setAmount(event.target.value);
          }}
   />
</div>
</div>
<div class="mb-3 row">
<label for="statieid" class="col-sm-2 col-form-label">Type_of_vehicle:</label>
<div class="col-sm-10">
<input type="text" readonly class="form-control" id="statieid" onChange={(event) => {
            setTov(event.target.value);
          }}
   />
</div>
</div>
<div class="mb-3 row">
<label for="statidid" class="col-sm-2 col-form-label">Payment_methods:</label>
<div class="col-sm-10">
<input type="text" readonly class="form-control" id="statidid" onChange={(event) => {
            setPayment(event.target.value);
          }}
   />
</div>
</div>
<div class="mb-3 row">
<label for="statidid" class="col-sm-2 col-form-label">Reg_number:</label>
<div class="col-sm-10">
<input type="text" readonly class="form-control" id="statidid" onChange={(event) => {
            setRegno(event.target.value);
          }}
   />
</div>
</div>
<div class="col-12">
<button type="submit" class="btn btn-primary" onClick={tax}>Assign</button>
</div>
</form>
  )
}

export default Insert_tax;