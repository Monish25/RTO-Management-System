import React from "react";

function Adminpage(){
    return(
        <div className="container">
            <div className="card mt-4">
              <div className="card-body">
                    <h2>Admin Page</h2>
                    <p> Welcome to the Administrator Page of Regional Transport Office Website</p>
              </div>
              <div class="col-12">
                <button type="submit" class="btn btn-primary">Apply</button>


                <button type="submit" class="btn btn-primary">Apply</button>


                <button type="submit" class="btn btn-primary">Apply</button>


                <button type="submit" class="btn btn-primary">Apply</button>
                </div>
            </div>
        </div>
    );

}

export default Adminpage;
