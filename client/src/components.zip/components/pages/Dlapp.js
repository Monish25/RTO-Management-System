import React, { useState } from 'react';
import Axios from 'axios';
import { useNavigate } from "react-router-dom";
function Dlapp({setNo}) {
    let navigate = useNavigate();
    const [appname, setAppName] = useState("");
    const [dob, setDob] = useState("");
    const [contact, setContact] = useState("");
    const [address, setAddress] = useState("");
    const [preferedrto, setPreferedRto] = useState("");
    var applicationno=Math.floor(1000 + Math.random() * 9000);
    const dapp = () => {    
        applicationno=Math.floor(1000 + Math.random() * 9000);
        setNo(applicationno);
            navigate("/Dlappd");
        Axios.post("http://localhost:3001/insert_driver_app",{
            DOB: dob,
            Applicant_name: appname,
            Contact: contact,
            Preffered_RTO: preferedrto,
            Address: address,
            Application_no: applicationno,
          }
          ).then(() => {
              
               console.log("suceeded");
          });
      };
  return (
    <form class="row g-3">
    <div><h3><centre>DRIVERS APPLICATION</centre></h3></div>
    <div class="mb-3 row">
<label for="staticid" class="col-sm-2 col-form-label">Applicant Name:</label>
<div class="col-sm-10">
<input type="text" readonly class="form-control" id="staticid" onChange={(event) => {
            setAppName(event.target.value);
          }}
   />
</div>
</div>
<div class="mb-3 row">
<label for="statiaid" class="col-sm-2 col-form-label">Date Of birth:</label>
<div class="col-sm-10">
<input type="date" readonly class="form-control" id="statiaid" placeholder='yyyy-mm-dd' min="2004-01-01" onChange={(event) => {
            setDob(event.target.value);
          }}
   />
</div>
</div>
<div class="mb-3 row">
<label for="statibid" class="col-sm-2 col-form-label">Contact:</label>
<div class="col-sm-10">
<input type="text" readonly class="form-control" id="statibid" onChange={(event) => {
            setContact(event.target.value);
          }}
   />
</div>
</div>
<div class="mb-3 row">
<label for="statieid" class="col-sm-2 col-form-label">Prefered RTO:</label>
<div class="col-sm-10">
<input type="text" readonly class="form-control" id="statieid" onChange={(event) => {
            setPreferedRto(event.target.value);
          }}
   />
</div>
</div>
<div class="mb-3 row">
<label for="statidid" class="col-sm-2 col-form-label">Address:</label>
<div class="col-sm-10">
<input type="text" readonly class="form-control" id="statidid" onChange={(event) => {
            setAddress(event.target.value);
          }}
   />
</div>
</div>
<div class="mb-3">
<label for="formFileSp" class="form-label">Photo:
</label>
<input class="form-control form-control-sm" id="formFileSp" type="file" />
</div>
<div class="col-12"></div>
<div class="mb-3">
<label for="formFileSm" class="form-label">Proof:</label>
<input class="form-control form-control-sm" id="formFileSm" type="file" />
</div>
<div class="col-12">
<button type="submit" class="btn btn-primary" onClick={dapp}>Apply</button>
</div>
</form>
  )
}

export default Dlapp;
