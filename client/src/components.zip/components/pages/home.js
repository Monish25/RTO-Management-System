import React from "react";

function Home(){
    return(
        <div className="container">
            <div className="card mt-4">
              <div className="card-body">
                    <h2>Home Page</h2>
                    <p> Welcome to the Regional Transport Office Website</p>
              </div>
            </div>
        </div>
    );

}

export default Home;
