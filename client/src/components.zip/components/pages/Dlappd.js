import React from 'react';
function Dlappd({no}) {

  return (
    <div>
      
      
      <h2>Your Application number is <p style={{ color: "blue" }}>{no}</p></h2>
      
      
      <h4><i>*Your DL application request is submitted please check after sometime for confirmation*</i></h4>
    </div>
  )
}

export default Dlappd;