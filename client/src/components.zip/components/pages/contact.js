import React from "react";

function Contact(){
    return(
        <div className="container">
            <div className="card mt-4">
              <div className="card-body">
                    <h2>Contact Page</h2>
                    <p>Cell:9975665661</p>
              </div>
            </div>
        </div>
    );

}

export default Contact;
