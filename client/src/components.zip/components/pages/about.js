import React from "react";

function About(){
    return(
        <div className="container">
            <div className="card mt-4">
              <div className="card-body">
                    <h2>About Page</h2>
                    <p>The RTO System was developed to address all the issues faced in the RTO System which can speed up the process and address the human errors in the records</p>
              </div>
            </div>
        </div>
    );

}

export default About;
